# 📋 أوامر سريعة للنسخ واللصق

## ✅ للبدء (خطوة بخطوة)

### 1. فك الضغط
```bash
tar -xzf sport-zone-gym-complete.tar.gz
cd sport-zone-project
```

### 2. تثبيت المكتبات
```bash
npm install
```

### 3. إعداد قاعدة البيانات
```bash
npm run setup
```

### 4. تشغيل البرنامج
```bash
npm run dev
```

### 5. افتح المتصفح
```
http://localhost:3000
```

---

## 🔐 بيانات الدخول

```
admin@sportzone.com
admin123
```

---

## 🛠️ أوامر مفيدة

### تشغيل البرنامج
```bash
npm run dev
```

### فتح مدير قاعدة البيانات
```bash
npm run db:studio
```

### نسخة احتياطية
```bash
cp prisma/dev.db prisma/backup-$(date +%Y%m%d).db
```

### إعادة إنشاء القاعدة
```bash
rm prisma/dev.db
npm run setup
```

---

## 🆘 حل المشاكل

### خطأ في npm
```bash
rm -rf node_modules package-lock.json
npm install
```

### إعادة تثبيت كاملة
```bash
rm -rf node_modules package-lock.json prisma/dev.db
npm install
npm run setup
```

---

## 📦 محتويات المشروع

```
✅ Prisma Schema (قاعدة البيانات)
✅ Next.js App (الواجهة)
✅ NextAuth (المصادقة)
✅ Tailwind CSS (التصميم)
✅ TypeScript (البرمجة)
✅ SQLite (قاعدة البيانات)
✅ شعار Sport Zone
✅ دعم RTL للعربية
✅ نظام offline كامل
```

---

## 🎯 الملفات المهمة

- `prisma/dev.db` - قاعدة البيانات (احفظ نسخة احتياطية!)
- `src/app/page.tsx` - الصفحة الرئيسية
- `prisma/schema.prisma` - تصميم الجداول
- `.env` - الإعدادات

---

## 📱 المراحل التالية

المرحلة 2: صفحات المشتركين
المرحلة 3: نظام الحضور
المرحلة 4: إدارة الاشتراكات
المرحلة 5: نظام المدفوعات
المرحلة 6: التقارير المتقدمة
المرحلة 7: الطباعة والإشعارات

---

## 💡 نصائح

✅ احفظ نسخة احتياطية يومية من dev.db
✅ غيّر كلمة المرور الافتراضية
✅ استخدم Chrome أو Edge للأداء الأفضل
✅ أغلق البرنامج بـ Ctrl+C في Terminal
✅ البرنامج لا يحتاج إنترنت أبداً

---

🎉 جاهز للاستخدام! 🚀
