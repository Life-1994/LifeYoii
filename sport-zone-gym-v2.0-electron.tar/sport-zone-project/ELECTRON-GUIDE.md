# 🖥️ دليل بناء برنامج Sport Zone للسطح المكتب

## ✨ نظرة عامة

تم تحويل Sport Zone إلى برنامج سطح مكتب كامل باستخدام **Electron**!

### المميزات:
- 🖥️ برنامج مستقل (لا يحتاج متصفح)
- 📦 ملف تثبيت سهل
- 🎨 ألوان وشعار Sport Zone
- 🌍 دعم كامل للعربية
- ⚡ offline تماماً
- 💾 قاعدة بيانات محلية
- 🔐 آمن ومشفر

---

## 📦 الأنظمة المدعومة

### Windows (ويندوز):
- ✅ Windows 10 / 11
- ✅ ملف تثبيت `.exe`
- ✅ اختصار في سطح المكتب
- ✅ قائمة ابدأ

### macOS (ماك):
- ✅ macOS 10.15+
- ✅ ملف `.dmg`
- ✅ Intel و Apple Silicon (M1/M2)

### Linux (لينكس):
- ✅ Ubuntu / Debian
- ✅ ملف `.AppImage`
- ✅ ملف `.deb`

---

## 🚀 خطوات البناء

### المتطلبات:
```bash
Node.js 18+ (مثبت ✓)
npm (مثبت ✓)
```

### الخطوة 1: التحديث للنسخة الإلكترونية

```bash
cd sport-zone-project

# نسخ الملفات الجديدة
cp package-electron.json package.json
cp next-config-electron.js next.config.js
cp electron-main.js electron/main.js
cp electron-preload.js electron/preload.js

# تثبيت المكتبات الجديدة
npm install
```

---

### الخطوة 2: بناء البرنامج

#### 🪟 بناء لـ Windows:
```bash
npm run electron:build-win
```

**النتيجة:**
```
dist/Sport-Zone-Setup-2.0.0.exe
```

---

#### 🍎 بناء لـ macOS:
```bash
npm run electron:build-mac
```

**النتيجة:**
```
dist/Sport-Zone-2.0.0.dmg
dist/Sport-Zone-2.0.0-arm64.dmg (للـ M1/M2)
```

---

#### 🐧 بناء لـ Linux:
```bash
npm run electron:build-linux
```

**النتيجة:**
```
dist/Sport-Zone-2.0.0.AppImage
dist/sport-zone-gym_2.0.0_amd64.deb
```

---

### الخطوة 3: التوزيع

#### الملفات الناتجة:

```
dist/
├── Sport-Zone-Setup-2.0.0.exe        (Windows)
├── Sport-Zone-2.0.0.dmg              (macOS Intel)
├── Sport-Zone-2.0.0-arm64.dmg        (macOS M1/M2)
├── Sport-Zone-2.0.0.AppImage         (Linux)
└── sport-zone-gym_2.0.0_amd64.deb    (Linux Debian/Ubuntu)
```

**الأحجام المتوقعة:**
- Windows: ~80-120 MB
- macOS: ~100-150 MB
- Linux: ~80-120 MB

---

## 🎨 الواجهة والألوان

### الألوان الرئيسية (حسب شعار Sport Zone):
```css
/* الألوان من الشعار */
--primary: #E67E22      /* برتقالي/ذهبي */
--secondary: #2C3E50    /* رمادي داكن */
--background: #f8fafc   /* رمادي فاتح */
--text: #1e293b         /* نص داكن */
```

### النافذة:
- ✅ أيقونة Sport Zone
- ✅ عنوان "Sport Zone"
- ✅ خلفية فاتحة
- ✅ حجم مناسب (1400x900)
- ✅ قابلة للتكبير/التصغير

### القائمة (عربي):
```
Sport Zone
├── حول البرنامج
├── إعادة التحميل
└── إنهاء

تحرير
├── تراجع
├── إعادة
├── قص
├── نسخ
└── لصق

عرض
├── ملء الشاشة
├── تكبير
├── تصغير
└── الحجم الطبيعي

نافذة
├── تصغير
└── إغلاق
```

---

## 🧪 الاختبار قبل البناء

### اختبار في وضع التطوير:
```bash
# تشغيل البرنامج في وضع Electron
npm run electron:dev
```

هذا سيفتح:
1. Next.js على المنفذ 3000
2. نافذة Electron تعرض البرنامج
3. DevTools للتطوير

**اختبر:**
- ✅ الشعار يظهر
- ✅ القوائم بالعربية
- ✅ الألوان صحيحة
- ✅ جميع الصفحات تعمل
- ✅ قاعدة البيانات تعمل

---

## 📝 ملاحظات مهمة

### 1. قاعدة البيانات:

في النسخة المكتوبة، قاعدة البيانات ستكون في:

**Windows:**
```
%APPDATA%\sport-zone-gym\prisma\dev.db
```

**macOS:**
```
~/Library/Application Support/sport-zone-gym/prisma/dev.db
```

**Linux:**
```
~/.config/sport-zone-gym/prisma/dev.db
```

### 2. التحديثات:

لإضافة نظام التحديثات التلقائية لاحقاً:
- استخدم `electron-updater`
- أضف خادم للتحديثات
- أو استخدم GitHub Releases

### 3. الأيقونات:

الأيقونات المطلوبة:
- `build/icon.ico` - Windows (256x256)
- `build/icon.icns` - macOS (512x512, 1024x1024)
- `build/icons/` - Linux (مختلف الأحجام)

**الحالي:** أيقونة PNG جاهزة، يمكن تحويلها لاحقاً

---

## 🔧 المشاكل الشائعة وحلولها

### المشكلة 1: خطأ في البناء
```bash
# احذف المجلدات وأعد التثبيت
rm -rf node_modules out dist
npm install
npm run electron:build-win
```

### المشكلة 2: الأيقونة لا تظهر
```bash
# تحقق من وجود الملفات:
ls build/icon.png     # يجب أن يكون موجود
ls build/icon.ico     # Windows (اختياري، سيتم إنشاؤه تلقائياً)
```

### المشكلة 3: البرنامج لا يعمل بعد التثبيت
```bash
# تأكد من بناء Next.js أولاً:
npm run build
# ثم ابنِ Electron:
npm run electron:build-win
```

---

## 🎯 نصائح للإنتاج

### 1. التوقيع الرقمي (Code Signing):

**Windows:**
- احصل على شهادة Code Signing
- وقّع الملف بـ SignTool

**macOS:**
- احصل على Apple Developer Account
- وقّع بـ `electron-osx-sign`

**Linux:**
- لا يحتاج توقيع

### 2. التحسينات:

```bash
# ضغط أفضل
npm run electron:build-win -- --config.compression=maximum

# بدون DevTools (حجم أصغر)
# عدّل في electron/main.js:
# isDev = false
```

### 3. الاختبار على أجهزة حقيقية:
- ✅ اختبر على Windows 10 و 11
- ✅ اختبر على macOS مختلفة
- ✅ اختبر على Ubuntu

---

## 📦 ملف التثبيت النهائي

### Windows (NSIS Installer):
```
Sport-Zone-Setup-2.0.0.exe

الميزات:
✅ اختيار مجلد التثبيت
✅ اختصار سطح المكتب
✅ قائمة ابدأ
✅ إلغاء التثبيت السهل
✅ التحديث فوق النسخة القديمة
```

### macOS (DMG):
```
Sport-Zone-2.0.0.dmg

الميزات:
✅ سحب وإفلات
✅ خلفية مخصصة
✅ أيقونة Sport Zone
✅ دعم M1/M2
```

### Linux (AppImage):
```
Sport-Zone-2.0.0.AppImage

الميزات:
✅ تشغيل مباشر (لا يحتاج تثبيت)
✅ محمول (portable)
✅ يعمل على معظم التوزيعات
```

---

## 🚀 الأوامر السريعة

```bash
# التطوير
npm run electron:dev                    # اختبار في Electron

# البناء
npm run electron:build                  # بناء للنظام الحالي
npm run electron:build-win              # Windows
npm run electron:build-mac              # macOS
npm run electron:build-linux            # Linux

# البناء لجميع الأنظمة (يحتاج إعداد خاص)
npm run electron:build -- --win --mac --linux
```

---

## ✅ قائمة التحقق قبل الإصدار

- [ ] تم اختبار جميع الصفحات
- [ ] قاعدة البيانات تعمل
- [ ] الأيقونات صحيحة
- [ ] القوائم بالعربية
- [ ] لا توجد أخطاء في Console
- [ ] الألوان مطابقة للشعار
- [ ] الحجم مناسب
- [ ] تم الاختبار على النظام المستهدف
- [ ] ملف LICENSE موجود
- [ ] اسم البرنامج صحيح

---

## 🎉 مبروك!

الآن عندك برنامج سطح مكتب كامل لـ Sport Zone!

**التالي:**
- [ ] اختبار شامل
- [ ] توزيع للمستخدمين
- [ ] جمع التعليقات
- [ ] إضافة ميزات جديدة

---

## 📞 الدعم

راجع:
- `ELECTRON-GUIDE.md` - هذا الملف
- `README.md` - الدليل الرئيسي
- `PHASE-2-GUIDE.md` - دليل الميزات

---

**© 2024 Sport Zone - المنطقة الرياضية**
**🏋️ إدارة احترافية لناديك الرياضي 🏋️**
